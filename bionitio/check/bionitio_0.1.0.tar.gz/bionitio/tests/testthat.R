library(testthat)
library(bionitio)

test_check("bionitio")
